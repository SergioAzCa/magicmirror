$("#boton1").click(function() {
	navigator.geolocation.getCurrentPosition(function(position) {
	  console.log(position.coords.latitude, position.coords.longitude);
	  var lat= position.coords.latitude;
	  var long= position.coords.longitude;
	  weatherReport(lat,long);

	});


		console.log("HOLA");
		//https://api.darksky.net/forecast/328d9ebcd87e9efeb1df8eaecc146730/39.5888456,-0.3306436?extend=hourly&callback=?
		//weatherReport(position.coords.latitude,position.coords.longitude);
			
	
});




function weatherReport(lat,long) {


	var apiKey           = '328d9ebcd87e9efeb1df8eaecc146730',
			url          = 'https://api.darksky.net/forecast/',
			lati         = lat,
			longi        = long,
			api_call     = url + apiKey + "/" + lat + "," + long+ "?lang=es&units=si&extend=hourly&callback=?";
			console.log(api_call);
	// Hold our days of the week for reference later.
	var days = [
		'Sunday',
		'Monday',
		'Tuesday',
		'Wednesday',
		'Thursday',
		'Friday',
		'Saturday'
	];

	var sunday    = [],
		monday    = [],
		tuesday   = [],
		wednesday = [],
		thursday  = [],
		friday    = [],
		saturday  = [];

	function hourlyReport(day, selector) {
		for(var i = 0, l = day.length; i < l; i++) {
			$("." + selector + " " + "ul").append('<li>' + Math.round(day[i]) + '</li>');
		}
	}

	// Call to the DarkSky API to retrieve JSON
	$.getJSON(api_call, function(forecast) {

		//DIA ACTUAL
			var date     = new Date(forecast.currently.time * 1000),
				abreviatura = forecast.currently.summary,
				skicons     = forecast.currently.icon,
				tiempo     = forecast.currently.time,
				viento     = forecast.currently.windSpeed,
				humidity = forecast.currently.humidity,
				summary  = forecast.currently.summary,
				temp    = forecast.currently.temperature,
				aparente_temp = forecast.currently.apparentTemperature,
				rocio = forecast.currently.dewPoint,
				nubes = forecast.currently.cloudCover,
				uv = 	forecast.currently.uvIndex,
				visibilidad = forecast.currently.visibility,
				ozono = forecast.currently.ozone;

		$("#tiempo").append(
					'<li class="shade-'+ skicons +'"><div class="card-container"><div><div class="front card"><div>' +
					"<div class='graphic'><canvas class=" + skicons + "></canvas></div>" +
					"<div><b>Día</b>: " + date.toLocaleDateString() + "</div>" +
					"<div><b>Temperatura</b>: " + temp + "</div>" +
					"<div><b>Temperatura aparente</b>: " + aparente_temp + "</div>" +
					"<div><b>Humedad</b>: " + humidity + "</div>" +
					"<div><b>Rocio</b>: " + rocio + "</div>" +
					"<div><b>Viento</b>: " + viento + "</div>" +
					"<div><b>Nubes</b>: " + nubes + "</div>" +
					"<div><b>índice UV</b>: " + uv + "</div>" +
					"<div><b>Visibilidad</b>: " + visibilidad + "</div>" +
					"<div><b>Ozono</b>: " + ozono + "</div>" +
					'</div></div><div class="back card">' 
					
			);


		// Bucle para las horas
		for(var j = 0, k = forecast.hourly.data.length; j < k; j++) {
			var hourly_date    = new Date(forecast.hourly.data[j].time * 1000),
					hourly_day     = days[hourly_date.getDay()],
					hourly_temp    = forecast.hourly.data[j].temperature;



			// Ponemos los valores de 24 horas en los array vacios
			switch(hourly_day) {
				case 'Sunday':
					sunday.push(hourly_temp);
					break;
				case 'Monday':
					monday.push(hourly_temp);
					break;
				case 'Tuesday':
					tuesday.push(hourly_temp);
					break;
				case 'Wednesday':
					wednesday.push(hourly_temp);
					break;
				case 'Thursday':
					thursday.push(hourly_temp);
					break;
				case 'Friday':
					friday.push(hourly_temp);
					break;
				case 'Saturday':
					saturday.push(hourly_temp);
					break;
				default: console.log(hourly_date.toLocaleTimeString());
					break;
			}
		}

		// Bucle para los días
		for(var i = 0, l = forecast.daily.data.length; i < l - 1; i++) {

			var date     = new Date(forecast.daily.data[i].time * 1000),
					day      = days[date.getDay()],
					skicons  = forecast.daily.data[i].icon,
					time     = forecast.daily.data[i].time,
					wind     = forecast.daily.data[i].windSpeed,
					humidity = forecast.daily.data[i].humidity,
					summary  = forecast.daily.data[i].summary,
					temp    = Math.round(forecast.hourly.data[i].temperature),
					tempMax = Math.round(forecast.daily.data[i].temperatureMax);



			// Append Markup for each Forecast of the 7 day week
			$("#forecast").append(
					'<li class="shade-'+ skicons +'"><div class="card-container"><div><div class="front card"><div>' +
					"<div class='graphic'><canvas class=" + skicons + "></canvas></div>" +
					"<div><b>Día</b>: " + date.toLocaleDateString() + "</div>" +
					"<div><b>Temperatura</b>: " + temp + "</div>" +
					"<div><b>Max Temp.</b>: " + tempMax + "</div>" +
					"<div><b>Humedad</b>: " + humidity + "</div>" +
					"<div><b>Viento</b>: " + wind + "</div>" +
					'</div></div><div class="back card">' 
					
			);

			// Daily forecast report for each day of the week
			switch(day) {
				case 'Sunday':
					hourlyReport(sunday, days[0]);
					break;
				case 'Monday':
					hourlyReport(monday, days[1]);
					break;
				case 'Tuesday':
					hourlyReport(tuesday, days[2]);
					break;
				case 'Wednesday':
					hourlyReport(wednesday, days[3]);
					break;
				case 'Thursday':
					hourlyReport(thursday, days[4]);
					break;
				case 'Friday':
					hourlyReport(friday, days[5]);
					break;
				case 'Saturday':
					hourlyReport(saturday, days[6]);
					break;
			}
		}
		
		skycons(); //Añadimos los iconos
		//staggerFade(); // fade-in forecast cards in a stagger-esque fashion

	});
}

function staggerFade() {
	setTimeout(function() {
		$('.fadein-stagger > *').each(function() {
			$(this).addClass('js-animated');
		})
	}, 30);
}

function skycons() {
        var i,
            icons = new Skycons({
               //"color" : "#190707",
               "color" : "#FF0000",
                "resizeClear": true // nasty android hack
            }),
            list  = [ // listing of all possible icons
                "clear-day",
                "clear-night",
                "partly-cloudy-day",
                "partly-cloudy-night",
                "cloudy",
                "rain",
                "sleet",
                "snow",
                "wind",
                "fog"
            ];
 
    // loop thru icon list array
    for(i = list.length; i--;) {
        var weatherType = list[i], // select each icon from list array
                // icons will have the name in the array above attached to the 
                // canvas element as a class so let's hook into them.
                elements    = document.getElementsByClassName( weatherType );
 
        // loop thru the elements now and set them up
        for (e = elements.length; e--;) {
            icons.set(elements[e], weatherType);
        }
    }
     
    // animate the icons
    icons.play();
}



